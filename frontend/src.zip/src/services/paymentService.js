import api from "./api";

export const payOrder = ({
  order_id,
  amount,
  payment_method = "demo",
  currency = "VND",
  gateway_transaction_id = "",
  blockchain_tx_hash = "",
  payer_wallet_address = "",
  gateway_response = {},
}) => {
  return api.post("/users/payments", {
    order_id,
    amount,
    payment_method,
    currency,
    gateway_transaction_id,
    blockchain_tx_hash,
    payer_wallet_address,
    gateway_response,
  });
};

export const getMyPayments = (params = {}) => {
  return api.get("/users/payments", { params });
};

export const getPaymentDetail = (paymentId) => {
  return api.get(`/users/payments/${paymentId}`);
};