import { useEffect, useMemo, useState } from "react";
import {
  Container,
  Card,
  Button,
  Alert,
  Form,
  Spinner,
  Table,
  Badge,
  Row,
  Col,
  Modal,
  Toast,
  ToastContainer,
} from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import { getOrderDetail } from "../services/orderService";
import { payOrder } from "../services/paymentService";
import { getMyWallet } from "../services/walletService";

function PaymentPage() {
  const { orderId } = useParams();
  const navigate = useNavigate();

  const [order, setOrder] = useState(null);
  const [items, setItems] = useState([]);
  const [payments, setPayments] = useState([]);
  const [linkedWallet, setLinkedWallet] = useState(null);
  const [walletLoading, setWalletLoading] = useState(true);

  const [paymentMethod, setPaymentMethod] = useState("demo");
  const [walletAddress, setWalletAddress] = useState("");
  const [gatewayTransactionId, setGatewayTransactionId] = useState("");

  const [connectedWallet, setConnectedWallet] = useState("");
  const [isConnectingWallet, setIsConnectingWallet] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [timeLeft, setTimeLeft] = useState(0);

  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [paidInfo, setPaidInfo] = useState({
    amount: 0,
    orderCode: "",
    method: "",
  });

  const formatTimeLeft = (seconds) => {
    if (seconds <= 0) return "00:00";

    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;

    return `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const shortenWallet = (address) => {
    if (!address) return "";
    if (address.length < 12) return address;
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const normalizeAddress = (address) => (address || "").trim().toLowerCase();

  const loadOrder = async () => {
    const response = await getOrderDetail(orderId);

    if (response.data?.success) {
      const payload = response.data.data;
      setOrder(payload);
      setItems(Array.isArray(payload.items) ? payload.items : []);
      setPayments(Array.isArray(payload.payments) ? payload.payments : []);

      if (payload.payment_status === "paid" && payload.order_status === "completed") {
        setSuccess("Thanh toán thành công. Đơn hàng đã hoàn tất.");
      } else if (
        payload.payment_status === "paid" &&
        payload.order_status === "processing"
      ) {
        setSuccess("Thanh toán thành công. Đơn hàng đang được hệ thống xử lý.");
      }
    } else {
      setError("Không lấy được thông tin đơn hàng");
    }
  };

  const loadWallet = async () => {
    try {
      setWalletLoading(true);
      const response = await getMyWallet();

      if (response.data?.success && response.data?.data) {
        const walletData = response.data.data;
        setLinkedWallet(walletData);
        setWalletAddress(walletData.wallet_address || "");
      } else {
        setLinkedWallet(null);
        setWalletAddress("");
      }
    } catch (err) {
      if (err.response?.status === 404) {
        setLinkedWallet(null);
        setWalletAddress("");
      } else {
        console.error("Lỗi khi lấy ví:", err);
      }
    } finally {
      setWalletLoading(false);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError("");
        setSuccess("");

        await Promise.all([loadOrder(), loadWallet()]);
      } catch (err) {
        setError(err.response?.data?.message || "Lỗi khi tải dữ liệu thanh toán");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [orderId]);

  useEffect(() => {
    if (!order?.expires_at) {
      setTimeLeft(0);
      return;
    }

    const updateCountdown = () => {
      const now = new Date().getTime();
      const expireTime = new Date(order.expires_at).getTime();
      const diff = Math.max(0, Math.floor((expireTime - now) / 1000));
      setTimeLeft(diff);
    };

    updateCountdown();

    const timer = setInterval(updateCountdown, 1000);

    return () => clearInterval(timer);
  }, [order]);

  useEffect(() => {
    if (paymentMethod !== "metamask") {
      setConnectedWallet("");
      setShowConfirmModal(false);
    }

    if (paymentMethod === "metamask" && linkedWallet?.wallet_address) {
      setWalletAddress(linkedWallet.wallet_address);
    }

    if (paymentMethod !== "metamask" && !linkedWallet?.wallet_address) {
      setWalletAddress("");
    }
  }, [paymentMethod, linkedWallet]);

  const latestPayment = useMemo(() => {
    if (!payments.length) return null;
    return payments[0];
  }, [payments]);

  const isPaid = order?.payment_status === "paid";
  const isExpired =
    order?.payment_status === "expired" ||
    order?.order_status === "expired" ||
    (order?.expires_at && timeLeft <= 0 && order?.payment_status !== "paid");

  const requiresMetaMaskFlow = paymentMethod === "metamask";

  const isWalletMatched =
    normalizeAddress(connectedWallet) &&
    normalizeAddress(linkedWallet?.wallet_address) &&
    normalizeAddress(connectedWallet) === normalizeAddress(linkedWallet?.wallet_address);

  const connectMetaMask = async () => {
    try {
      setError("");
      setSuccess("");

      if (!linkedWallet?.wallet_address) {
        setError("Tài khoản chưa liên kết ví. Vui lòng vào Hồ sơ để liên kết ví trước.");
        return;
      }

      if (typeof window === "undefined" || !window.ethereum) {
        setError("Trình duyệt chưa có MetaMask. Vui lòng cài extension MetaMask trước.");
        return;
      }

      setIsConnectingWallet(true);

      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      });

      const selectedAccount = Array.isArray(accounts) ? accounts[0] : "";

      if (!selectedAccount) {
        setError("Không lấy được địa chỉ ví từ MetaMask.");
        return;
      }

      setConnectedWallet(selectedAccount);

      if (
        normalizeAddress(selectedAccount) !==
        normalizeAddress(linkedWallet.wallet_address)
      ) {
        setError(
          "Ví đang kết nối trên MetaMask không trùng với ví đã liên kết trong tài khoản."
        );
        return;
      }

      setSuccess("Kết nối MetaMask thành công. Bạn có thể xác nhận thanh toán.");
    } catch (err) {
      if (err?.code === 4001) {
        setError("Bạn đã từ chối kết nối MetaMask.");
      } else {
        setError("Không thể kết nối MetaMask.");
      }
    } finally {
      setIsConnectingWallet(false);
    }
  };

  const submitPayment = async (payerWalletAddress = "") => {
    const response = await payOrder({
      order_id: Number(order.id),
      amount: Number(order.total_amount),
      payment_method: paymentMethod,
      currency: "VND",
      gateway_transaction_id: gatewayTransactionId.trim(),
      blockchain_tx_hash: "",
      payer_wallet_address: payerWalletAddress,
      gateway_response: {
        source: requiresMetaMaskFlow ? "frontend-metamask-level-1" : "frontend-demo",
        submitted_at: new Date().toISOString(),
      },
    });

    if (response.data?.success) {
      const nextOrder =
        response.data?.data?.order ||
        response.data?.data?.updatedOrder ||
        response.data?.data?.order_data ||
        null;

      setSuccess("Thanh toán thành công. Đơn hàng đã được cập nhật thành công.");

      setPaidInfo({
        amount: Number(
          nextOrder?.total_amount ||
            order?.total_amount ||
            0
        ),
        orderCode: nextOrder?.order_code || order?.order_code || "",
        method: paymentMethod,
      });

      setShowSuccessToast(true);

      await loadOrder();
      setShowConfirmModal(false);
    } else {
      setError(response.data?.message || "Không thể thanh toán đơn hàng");
    }
  };

  const handleNormalPayment = async () => {
    try {
      if (!order) return;

      if (isExpired) {
        setError("Đơn hàng đã hết thời gian thanh toán.");
        return;
      }

      setPaying(true);
      setError("");
      setSuccess("");

      await submitPayment(walletAddress.trim());
    } catch (err) {
      setError(err.response?.data?.message || "Lỗi khi xử lý thanh toán");
    } finally {
      setPaying(false);
    }
  };

  const handleOpenMetaMaskConfirm = () => {
    setError("");
    setSuccess("");

    if (!linkedWallet?.wallet_address) {
      setError("Tài khoản chưa liên kết ví. Vui lòng vào Hồ sơ để liên kết ví trước.");
      return;
    }

    if (!connectedWallet) {
      setError("Vui lòng kết nối MetaMask trước khi thanh toán.");
      return;
    }

    if (!isWalletMatched) {
      setError("Ví MetaMask hiện tại không khớp với ví đã liên kết trong tài khoản.");
      return;
    }

    if (isExpired) {
      setError("Đơn hàng đã hết thời gian thanh toán.");
      return;
    }

    setShowConfirmModal(true);
  };

  const handleConfirmMetaMaskPayment = async () => {
    try {
      if (!order) return;

      setPaying(true);
      setError("");
      setSuccess("");

      await submitPayment(connectedWallet.trim());
    } catch (err) {
      setError(err.response?.data?.message || "Lỗi khi xử lý thanh toán");
    } finally {
      setPaying(false);
    }
  };

  const getPaymentBadge = (status) => {
    switch (status) {
      case "paid":
        return "success";
      case "failed":
        return "danger";
      case "expired":
        return "secondary";
      case "refunded":
        return "dark";
      default:
        return "warning";
    }
  };

  const getOrderBadge = (status) => {
    switch (status) {
      case "awaiting_payment":
        return "warning";
      case "processing":
        return "info";
      case "completed":
        return "success";
      case "cancelled":
        return "secondary";
      case "expired":
        return "dark";
      default:
        return "warning";
    }
  };

  const renderPaymentText = (status) => {
    switch (status) {
      case "pending":
        return "Chờ thanh toán";
      case "paid":
        return "Đã thanh toán";
      case "failed":
        return "Thất bại";
      case "expired":
        return "Hết hạn";
      case "refunded":
        return "Đã hoàn tiền";
      default:
        return status || "Không xác định";
    }
  };

  const renderOrderText = (status) => {
    switch (status) {
      case "awaiting_payment":
        return "Chờ thanh toán";
      case "processing":
        return "Đang xử lý";
      case "completed":
        return "Hoàn tất";
      case "cancelled":
        return "Đã hủy";
      case "expired":
        return "Hết hạn";
      default:
        return status || "Không xác định";
    }
  };

  if (loading) {
    return (
      <div
        className="d-flex justify-content-center align-items-center"
        style={{ minHeight: "70vh" }}
      >
        <Spinner animation="border" />
      </div>
    );
  }

  if (!order) {
    return (
      <Container className="user-shell text-center">
        <h3>Không tìm thấy đơn hàng</h3>
      </Container>
    );
  }

  return (
    <>
      <Container className="user-shell">
        <Row className="g-4">
          <Col lg={8}>
            <Card className="payment-card">
              <Card.Body className="p-4 p-lg-5">
                <div className="section-title mb-2">Thanh toán đơn hàng</div>
                <div className="section-subtitle mb-4">
                  Mức 1 Metamask: kết nối ví, đối chiếu ví đã liên kết, xác nhận thanh toán trên giao diện rồi gửi backend ghi nhận.
                </div>

                {error && <Alert variant="danger">{error}</Alert>}
                {success && <Alert variant="success">{success}</Alert>}

                {order?.expires_at && !isPaid && (
                  <Alert variant={isExpired ? "danger" : "warning"}>
                    {isExpired ? (
                      <>Đơn hàng đã hết thời gian thanh toán.</>
                    ) : (
                      <>
                        Thời gian còn lại để thanh toán:{" "}
                        <strong>{formatTimeLeft(timeLeft)}</strong>
                      </>
                    )}
                  </Alert>
                )}

                <Row className="g-3 mb-4">
                  <Col md={6}>
                    <div className="payment-summary-box">
                      <div className="text-muted mb-1">Mã đơn</div>
                      <div className="fw-bold fs-5">{order.order_code}</div>
                    </div>
                  </Col>

                  <Col md={6}>
                    <div className="payment-summary-box">
                      <div className="text-muted mb-1">Tổng tiền</div>
                      <div className="fw-bold fs-5">
                        {Number(order.total_amount).toLocaleString("vi-VN")} VND
                      </div>
                    </div>
                  </Col>
                </Row>

                <div className="d-flex gap-3 flex-wrap mb-4">
                  <Badge bg={getPaymentBadge(order.payment_status)} className="status-badge">
                    Thanh toán: {renderPaymentText(order.payment_status)}
                  </Badge>

                  <Badge bg={getOrderBadge(order.order_status)} className="status-badge">
                    Đơn hàng: {renderOrderText(order.order_status)}
                  </Badge>
                </div>

                <h5 className="fw-bold mb-3">Chi tiết vé</h5>

                <Table responsive hover className="table-modern align-middle mb-4">
                  <thead>
                    <tr>
                      <th>Loại vé</th>
                      <th>Số lượng</th>
                      <th>Đơn giá</th>
                      <th>Thành tiền</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item) => (
                      <tr key={item.id}>
                        <td className="fw-semibold">{item.ticket_type_name_snapshot}</td>
                        <td>{item.quantity}</td>
                        <td>{Number(item.unit_price).toLocaleString("vi-VN")} VND</td>
                        <td>{Number(item.subtotal).toLocaleString("vi-VN")} VND</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>

                {!isPaid && !isExpired && (
                  <>
                    <Form.Group className="mb-3">
                      <Form.Label>Phương thức thanh toán</Form.Label>
                      <Form.Select
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                      >
                        <option value="demo">Demo</option>
                        <option value="bank_transfer">Chuyển khoản</option>
                        <option value="cash">Tiền mặt</option>
                        <option value="stripe">Stripe</option>
                        <option value="metamask">Metamask</option>
                      </Form.Select>
                    </Form.Group>

                    {requiresMetaMaskFlow ? (
                      <>
                        {walletLoading ? (
                          <Alert variant="info">Đang tải thông tin ví đã liên kết...</Alert>
                        ) : linkedWallet ? (
                          <Alert variant="success">
                            Ví đã liên kết trong tài khoản:{" "}
                            <strong>{linkedWallet.wallet_address}</strong>
                            <br />
                            Mạng: <strong>{linkedWallet.network_name}</strong>
                          </Alert>
                        ) : (
                          <Alert variant="warning">
                            Tài khoản này chưa liên kết ví. Vào <strong>Hồ sơ</strong> để liên kết ví trước khi thanh toán bằng Metamask.
                          </Alert>
                        )}

                        <Form.Group className="mb-3">
                          <Form.Label>Địa chỉ ví liên kết</Form.Label>
                          <Form.Control
                            type="text"
                            value={walletAddress}
                            readOnly
                            placeholder="Chưa có ví liên kết"
                          />
                        </Form.Group>

                        {connectedWallet && (
                          <Alert variant={isWalletMatched ? "success" : "danger"}>
                            Ví đang kết nối MetaMask: <strong>{connectedWallet}</strong>
                            <br />
                            Trạng thái:{" "}
                            <strong>
                              {isWalletMatched ? "Khớp với ví đã liên kết" : "Không khớp với ví đã liên kết"}
                            </strong>
                          </Alert>
                        )}

                        <div className="d-flex gap-3 flex-wrap mb-4">
                          <Button
                            className="soft-button soft-button-outline"
                            onClick={connectMetaMask}
                            disabled={isConnectingWallet || walletLoading || !linkedWallet}
                          >
                            {isConnectingWallet ? "Đang kết nối..." : "Kết nối MetaMask"}
                          </Button>

                          {!linkedWallet && (
                            <Button
                              className="soft-button soft-button-dark"
                              onClick={() => navigate("/profile")}
                            >
                              Đi tới hồ sơ để liên kết ví
                            </Button>
                          )}
                        </div>
                      </>
                    ) : (
                      <Form.Group className="mb-4">
                        <Form.Label>Mã giao dịch cổng thanh toán</Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="Có thể để trống với chế độ demo"
                          value={gatewayTransactionId}
                          onChange={(e) => setGatewayTransactionId(e.target.value)}
                        />
                      </Form.Group>
                    )}
                  </>
                )}

                <div className="d-flex gap-3 flex-wrap">
                  {!isPaid && !isExpired && !requiresMetaMaskFlow && (
                    <Button
                      className="soft-button soft-button-primary"
                      onClick={handleNormalPayment}
                      disabled={paying}
                    >
                      {paying ? "Đang xử lý..." : "Thanh toán ngay"}
                    </Button>
                  )}

                  {!isPaid && !isExpired && requiresMetaMaskFlow && (
                    <Button
                      className="soft-button soft-button-primary"
                      onClick={handleOpenMetaMaskConfirm}
                      disabled={paying || walletLoading || !linkedWallet}
                    >
                      {paying ? "Đang xử lý..." : "Thanh toán bằng MetaMask"}
                    </Button>
                  )}

                  <Button
                    className="soft-button soft-button-dark"
                    onClick={() => navigate("/profile")}
                  >
                    Về hồ sơ
                  </Button>
                </div>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={4}>
            <Card className="payment-card mb-4">
              <Card.Body className="p-4">
                <div className="section-title mb-3" style={{ fontSize: "1.4rem" }}>
                  Tiến trình
                </div>

                <div className="d-flex flex-column gap-3">
                  <div className="payment-summary-box">
                    <div className="fw-bold">1. Tạo đơn hàng</div>
                    <div className="text-muted">Đã hoàn tất</div>
                  </div>

                  <div className="payment-summary-box">
                    <div className="fw-bold">2. Thanh toán</div>
                    <div className="text-muted">{isPaid ? "Đã hoàn tất" : "Chưa hoàn tất"}</div>
                  </div>

                  <div className="payment-summary-box">
                    <div className="fw-bold">3. Xử lý đơn</div>
                    <div className="text-muted">
                      {order.order_status === "processing"
                        ? "Đơn đang được xử lý"
                        : order.order_status === "completed"
                        ? "Đã hoàn tất"
                        : "Chờ xử lý"}
                    </div>
                  </div>

                  <div className="payment-summary-box">
                    <div className="fw-bold">4. Issue/Mint vé</div>
                    <div className="text-muted">Luồng này do admin/backend xử lý sau.</div>
                  </div>
                </div>
              </Card.Body>
            </Card>

            <Card className="payment-card">
              <Card.Body className="p-4">
                <div className="section-title mb-3" style={{ fontSize: "1.4rem" }}>
                  Lần thanh toán gần nhất
                </div>

                {latestPayment ? (
                  <div className="payment-summary-box">
                    <div className="mb-2">
                      <strong>Mã thanh toán:</strong> {latestPayment.payment_code}
                    </div>
                    <div className="mb-2">
                      <strong>Phương thức:</strong> {latestPayment.payment_method}
                    </div>
                    <div className="mb-2">
                      <strong>Số tiền:</strong>{" "}
                      {Number(latestPayment.amount).toLocaleString("vi-VN")}{" "}
                      {latestPayment.currency}
                    </div>
                    <div className="mb-2">
                      <strong>Trạng thái:</strong> {latestPayment.status}
                    </div>
                    <div>
                      <strong>Thời gian:</strong>{" "}
                      {latestPayment.paid_at
                        ? new Date(latestPayment.paid_at).toLocaleString("vi-VN")
                        : "Chưa thanh toán"}
                    </div>
                  </div>
                ) : (
                  <div className="text-muted">Chưa có bản ghi thanh toán nào.</div>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>

      <Modal
        show={showConfirmModal}
        onHide={() => !paying && setShowConfirmModal(false)}
        centered
      >
        <Modal.Header closeButton={!paying}>
          <Modal.Title>Xác nhận thanh toán bằng MetaMask</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <div className="mb-3">
            <strong>Mã đơn:</strong> {order?.order_code}
          </div>
          <div className="mb-3">
            <strong>Tổng tiền:</strong>{" "}
            {Number(order?.total_amount || 0).toLocaleString("vi-VN")} VND
          </div>
          <div className="mb-3">
            <strong>Ví đã liên kết:</strong>{" "}
            {linkedWallet?.wallet_address || "Không có"}
          </div>
          <div className="mb-3">
            <strong>Ví MetaMask đang kết nối:</strong>{" "}
            {connectedWallet || "Chưa kết nối"}
          </div>
          <div className="text-muted">
            Sau khi bấm xác nhận, frontend sẽ gửi thông tin thanh toán MetaMask về backend để hệ thống ghi nhận thanh toán.
          </div>
        </Modal.Body>

        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => setShowConfirmModal(false)}
            disabled={paying}
          >
            Hủy
          </Button>
          <Button
            className="soft-button soft-button-primary"
            onClick={handleConfirmMetaMaskPayment}
            disabled={paying || !isWalletMatched}
          >
            {paying ? "Đang xử lý..." : "Xác nhận thanh toán"}
          </Button>
        </Modal.Footer>
      </Modal>

      <ToastContainer
        position="top-end"
        className="p-3"
        style={{ zIndex: 2000 }}
      >
        <Toast
          bg="success"
          onClose={() => setShowSuccessToast(false)}
          show={showSuccessToast}
          delay={4500}
          autohide
        >
          <Toast.Header closeButton>
            <strong className="me-auto">Thanh toán thành công</strong>
            <small>Vừa xong</small>
          </Toast.Header>
          <Toast.Body className="text-white">
            Đã trừ số tiền{" "}
            <strong>{Number(paidInfo.amount || 0).toLocaleString("vi-VN")} VND</strong>{" "}
            cho đơn hàng <strong>{paidInfo.orderCode}</strong>.
            <br />
            Phương thức: <strong>{paidInfo.method}</strong>
          </Toast.Body>
        </Toast>
      </ToastContainer>
    </>
  );
}

export default PaymentPage;