import React from "react";
import { Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,
  Button,
  Table,
  Badge,
  ProgressBar,
} from "react-bootstrap";
import "../../styles/admin-main.css";

function AdminDashboardPage() {
  const stats = [
    {
      title: "Tổng sự kiện",
      value: 12,
      change: "+8%",
      icon: "🎤",
      subtitle: "Đang hoạt động và sắp diễn ra",
    },
    {
      title: "Tổng vé đã bán",
      value: 3250,
      change: "+15%",
      icon: "🎟️",
      subtitle: "Tính trên toàn hệ thống",
    },
    {
      title: "Doanh thu",
      value: "1.2 tỷ",
      change: "+12%",
      icon: "💰",
      subtitle: "Doanh thu tháng này",
    },
    {
      title: "Người dùng",
      value: 842,
      change: "+5%",
      icon: "👤",
      subtitle: "Tài khoản đã đăng ký",
    },
  ];

  const recentEvents = [
    {
      id: 1,
      name: "Liveshow Sơn Tùng M-TP 2026",
      date: "30/06/2026",
      location: "TP.HCM",
      status: "Đang mở bán",
    },
    {
      id: 2,
      name: "Noo Phước Thịnh Live Concert",
      date: "12/07/2026",
      location: "Hà Nội",
      status: "Sắp diễn ra",
    },
    {
      id: 3,
      name: "Rap Việt All Stars",
      date: "25/07/2026",
      location: "Đà Nẵng",
      status: "Tạm dừng",
    },
  ];

  const recentOrders = [
    {
      id: "ORD001",
      customer: "Nguyễn Văn A",
      amount: "3.000.000đ",
      status: "Đã thanh toán",
    },
    {
      id: "ORD002",
      customer: "Trần Thị B",
      amount: "5.000.000đ",
      status: "Chờ thanh toán",
    },
    {
      id: "ORD003",
      customer: "Lê Văn C",
      amount: "2.000.000đ",
      status: "Đã hoàn tiền",
    },
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case "Đang mở bán":
      case "Đã thanh toán":
        return "success";
      case "Sắp diễn ra":
      case "Chờ thanh toán":
        return "warning";
      case "Tạm dừng":
        return "secondary";
      case "Đã hoàn tiền":
        return "danger";
      default:
        return "primary";
    }
  };

  return (
    <>
      <div className="admin-topbar">
        <div>
          <h2 className="admin-page-title">Dashboard quản trị</h2>
          <p className="admin-page-subtitle">
            Theo dõi hệ thống bán vé concert một cách trực quan và chuyên nghiệp
          </p>
        </div>

        <div className="admin-topbar-actions">
          <Button variant="outline-dark" className="me-2">
            Xuất báo cáo
          </Button>
          <Button as={Link} to="/admin/events" className="admin-primary-btn">
            Quản lý sự kiện
          </Button>
        </div>
      </div>

      <Container fluid className="p-0">
        <Row className="g-4 mb-4">
          {stats.map((item, index) => (
            <Col lg={3} md={6} key={index}>
              <Card className="admin-stat-card">
                <Card.Body>
                  <div className="admin-stat-top">
                    <div>
                      <p className="admin-stat-title">{item.title}</p>
                      <h3 className="admin-stat-value">{item.value}</h3>
                    </div>
                    <div className="admin-stat-icon">{item.icon}</div>
                  </div>
                  <div className="admin-stat-bottom">
                    <span className="admin-stat-change">{item.change}</span>
                    <span className="admin-stat-subtitle">{item.subtitle}</span>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>

        <Row className="g-4 mb-4">
          <Col lg={8}>
            <Card className="admin-card h-100">
              <Card.Body>
                <div className="admin-card-header">
                  <div>
                    <h5 className="mb-1">Hiệu suất bán vé</h5>
                    <p className="text-muted mb-0">Tổng quan tiến độ phân phối vé</p>
                  </div>
                  <Badge bg="dark">Tháng này</Badge>
                </div>

                <div className="mt-4">
                  <div className="admin-progress-item">
                    <div className="d-flex justify-content-between mb-2">
                      <span>VVIP</span>
                      <span>80%</span>
                    </div>
                    <ProgressBar now={80} />
                  </div>

                  <div className="admin-progress-item">
                    <div className="d-flex justify-content-between mb-2">
                      <span>VIP</span>
                      <span>62%</span>
                    </div>
                    <ProgressBar now={62} />
                  </div>

                  <div className="admin-progress-item">
                    <div className="d-flex justify-content-between mb-2">
                      <span>STANDARD</span>
                      <span>45%</span>
                    </div>
                    <ProgressBar now={45} />
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={4}>
            <Card className="admin-card h-100">
              <Card.Body>
                <div className="admin-card-header">
                  <div>
                    <h5 className="mb-1">Tóm tắt hệ thống</h5>
                    <p className="text-muted mb-0">Thông tin nhanh</p>
                  </div>
                </div>

                <div className="admin-summary-box">
                  <div className="admin-summary-item">
                    <span>Sự kiện đang mở bán</span>
                    <strong>6</strong>
                  </div>
                  <div className="admin-summary-item">
                    <span>Vé đã check-in</span>
                    <strong>1,248</strong>
                  </div>
                  <div className="admin-summary-item">
                    <span>Yêu cầu hoàn tiền</span>
                    <strong>14</strong>
                  </div>
                  <div className="admin-summary-item">
                    <span>Tỷ lệ check-in</span>
                    <strong>78%</strong>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <Row className="g-4">
          <Col lg={7}>
            <Card className="admin-card">
              <Card.Body>
                <div className="admin-card-header">
                  <div>
                    <h5 className="mb-1">Sự kiện gần đây</h5>
                    <p className="text-muted mb-0">
                      Danh sách sự kiện mới nhất trong hệ thống
                    </p>
                  </div>
                  <Button as={Link} to="/admin/events" variant="outline-dark" size="sm">
                    Xem tất cả
                  </Button>
                </div>

                <div className="table-responsive mt-3">
                  <Table hover className="admin-table align-middle">
                    <thead>
                      <tr>
                        <th>Tên sự kiện</th>
                        <th>Ngày diễn ra</th>
                        <th>Địa điểm</th>
                        <th>Trạng thái</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentEvents.map((event) => (
                        <tr key={event.id}>
                          <td className="fw-semibold">{event.name}</td>
                          <td>{event.date}</td>
                          <td>{event.location}</td>
                          <td>
                            <Badge bg={getStatusBadge(event.status)}>
                              {event.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={5}>
            <Card className="admin-card">
              <Card.Body>
                <div className="admin-card-header">
                  <div>
                    <h5 className="mb-1">Đơn hàng gần đây</h5>
                    <p className="text-muted mb-0">Theo dõi giao dịch mới</p>
                  </div>
                </div>

                <div className="mt-3">
                  {recentOrders.map((order, index) => (
                    <div className="admin-order-item" key={index}>
                      <div>
                        <h6 className="mb-1">{order.id}</h6>
                        <p className="mb-0 text-muted">{order.customer}</p>
                      </div>
                      <div className="text-end">
                        <strong>{order.amount}</strong>
                        <div>
                          <Badge bg={getStatusBadge(order.status)}>
                            {order.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default AdminDashboardPage;