import React, { useEffect } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Button, Form } from "react-bootstrap";
import "../../styles/admin-main.css";

function AdminLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "null");

  const isActive = (path) => location.pathname === path;

  useEffect(() => {
    document.body.classList.add("admin-body");

    return () => {
      document.body.classList.remove("admin-body");
    };
  }, []);

 const handleLogout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  document.body.classList.remove("admin-body");
  navigate("/login");
};

  return (
    <div className="admin-page">
      <div className="admin-sidebar">
        <div className="admin-brand">
          <div className="admin-brand-logo">CT</div>
          <div>
            <h5>Concert Admin</h5>
            <span>Quản trị hệ thống</span>
          </div>
        </div>

        <div className="admin-menu">
          <p className="admin-menu-title">Tổng quan</p>
          <Link
            to="/admin"
            className={`admin-menu-item ${isActive("/admin") ? "active" : ""}`}
          >
            <span>📊</span> Dashboard
          </Link>

          <p className="admin-menu-title">Quản lý</p>
          <Link
            to="/admin/events"
            className={`admin-menu-item ${isActive("/admin/events") ? "active" : ""}`}
          >
            <span>🎤</span> Quản lý sự kiện
          </Link>

          <Link
           to="/admin/ticket-types"
           className={`admin-menu-item ${isActive("/admin/ticket-types") ? "active" : ""}`}
          >
            <span>🎟️</span> Quản lý vé
          </Link>

          <button className="admin-menu-item">
            <span>🧾</span> Quản lý đơn hàng
          </button>

          <button className="admin-menu-item">
            <span>👥</span> Quản lý người dùng
          </button>

          <button className="admin-menu-item">
            <span>✅</span> Check-in
          </button>
        </div>
      </div>

      <div className="admin-content">
        <div className="admin-layout-header">
          <div className="admin-layout-header-left">
            <div className="admin-layout-breadcrumb">
              <span>Admin</span>
              <span className="admin-breadcrumb-separator">/</span>
              <strong>
                {location.pathname === "/admin"
                  ? "Dashboard"
                  : location.pathname === "/admin/events"
                  ? "Quản lý sự kiện"
                  : "Quản trị"}
              </strong>
            </div>

            <h3 className="admin-layout-title">
              Xin chào, {user?.full_name || "Admin"}
            </h3>

            <p className="admin-layout-subtitle">
              Quản lý hệ thống bán vé concert một cách trực quan và chuyên nghiệp.
            </p>
          </div>

          <div className="admin-layout-header-right">
            <div className="admin-search-box">
              <Form.Control type="text" placeholder="Tìm nhanh trong trang admin..." />
            </div>

            <Button
              as={Link}
              to="/home"
              variant="outline-dark"
              className="admin-header-btn"
            >
              Về trang user
            </Button>

            <div className="admin-header-user">
              <div className="admin-header-avatar">
                {(user?.full_name || user?.email || "A").charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="admin-header-user-name">
                  {user?.full_name || "Admin"}
                </div>
                <div className="admin-header-user-role">
                  {user?.role || "admin"}
                </div>
              </div>
            </div>

            <Button
              variant="danger"
              className="admin-header-btn"
              onClick={handleLogout}
            >
              Đăng xuất
            </Button>
          </div>
        </div>

        <Outlet />
      </div>
    </div>
  );
}

export default AdminLayout;