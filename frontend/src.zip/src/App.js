import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { useState } from "react";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import EventDetailPage from "./pages/EventDetailPage";
import ProfilePage from "./pages/ProfilePage";
import PaymentPage from "./pages/PaymentPage";
import AppNavbar from "./components/AppNavbar";
import LandingPage from "./pages/LandingPage";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import AdminEventPage from "./pages/admin/AdminEventPage";
import AdminTicketTypePage from "./pages/admin/AdminTicketTypePage";
import Footer from "./components/Footer";
import "./styles/user-ui.css";
import TicketTransferPage from "./pages/TicketTransferPage";
import MyIncomingTransfersPage from "./pages/MyIncomingTransfersPage";
function getStoredUser() {
  try {
    const rawUser = localStorage.getItem("user");
    if (!rawUser || rawUser === "undefined") return null;
    return JSON.parse(rawUser);
  } catch (error) {
    localStorage.removeItem("user");
    return null;
  }
}

function AppContent() {
  const location = useLocation();
  const [user, setUser] = useState(getStoredUser());

  const isAdmin = user?.role === "admin";
  const isAdminPath = location.pathname.startsWith("/admin");

  return (
    <div
      style={{
        fontFamily: "Inter",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {!isAdminPath && <AppNavbar user={user} setUser={setUser} />}

      <main style={{ flex: 1 }}>
        <Routes>
          <Route path="/" element={user ? <HomePage /> : <LandingPage />} />
          <Route path="/event/:eventId" element={<EventDetailPage />} />

          <Route
            path="/home"
            element={user ? <HomePage /> : <Navigate to="/login" />}
          />

          <Route
            path="/profile"
            element={user ? <ProfilePage setUser={setUser} /> : <Navigate to="/login" />}
          />

          <Route
            path="/payment/:orderId"
            element={user ? <PaymentPage /> : <Navigate to="/login" />}
          />

          <Route
            path="/login"
            element={
              !user ? <LoginPage setUser={setUser} /> : <Navigate to="/home" />
            }
          />
            <Route path="/ticket-transfer" element={<TicketTransferPage />} />
<Route path="/incoming-transfers" element={<MyIncomingTransfersPage />} />
          <Route
            path="/register"
            element={!user ? <RegisterPage /> : <Navigate to="/home" />}
          />

          <Route
            path="/admin"
            element={user && isAdmin ? <AdminLayout /> : <Navigate to="/login" />}
          >
            <Route index element={<AdminDashboardPage />} />
            <Route path="events" element={<AdminEventPage />} />
            <Route path="ticket-types" element={<AdminTicketTypePage />} />
          </Route>

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>

      {!isAdminPath && <Footer />}
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}

export default App;